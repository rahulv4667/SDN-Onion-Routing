from enum import Enum


class  DirectoryActions(Enum):
    RegisterReq = 1
    RegisterResp = 2
    FetchReq = 3
    FetchResp = 4
    NA = 5



class TorDirectoryPacket:
    def __init__(self, action: DirectoryActions, payload: bytes, success: bool = False):
        self.action = action
        self.payload = payload
        self.success = success

class RelayServerDetails:
    def __init__(self, ip: str, port:int, pubkey:str):
        self.ip = ip
        self.port = port
        self.pubkey = pubkey