from os import name
import threading
import socket
import pickle
import sys
# import TorHelper as Tor
import random
from DirectoryHelper import TorDirectoryPacket, DirectoryActions, RelayServerDetails

def recvall(sock):
    BUFF_SIZE = 4096 # 4 KiB
    data = b''
    while True:
        part = sock.recv(BUFF_SIZE)
        data += part
        if len(part) < BUFF_SIZE:
            # either 0 or end of data
            break
    return data



class DirectoryService:
    relay_node_list = list()

    def __init__(self, port):
        print("Initializing directory service...")
        self.hostname = socket.gethostname()
        self.IPAddr = socket.gethostbyname(self.hostname)
        self.host = self.IPAddr
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))
        print('Initialization of directory service at {}:{} complete ...'.format(self.host,self.port))
        print("Initialization of directory service complete...")

    def startListening(self):
        print("Starting to listen for relay nodes...")
        self.sock.listen(50)
        f = open('client_entries','w+')
        while True:
            client, address = self.sock.accept()
            f.write("{} .... {}\n".format(client, address))
            client.settimeout(60)
            threading.Thread(target=self.listenToRelay, args=(client, address)).start()

    def listenToRelay(self, client: socket.socket, address):
        # size = 1024
        print("Relay connected")
        while True:
            try:
                # data = client.recv(size)
                data = recvall(client)
                if data:
                    packet = pickle.loads(data)
                    print('received packet: {}'.format(packet))
                    response = self.handle_connection(address, packet)
                    # Set the response to echo back the received data
                    client.sendall(response)
                else:
                    raise Exception('Relay node disconnected')
            except Exception as e:
                print(e)
                client.close()
                return False

    def handle_connection(self, address, packet: TorDirectoryPacket):
        if(packet.action == DirectoryActions.RegisterReq):
            msg = packet.payload
            if msg['port'] is None or msg['pubkey'] is None:
                resp = TorDirectoryPacket(action=DirectoryActions.RegisterResp, payload=None, success=False)
                return pickle.dumps(resp)

            r = RelayServerDetails(
                # name=packet.Uid, 
                # ip=packet.Dst, 
                ip=address,
                port=msg['port'], 
                pubkey=msg['pubkey']
            )
            self.relay_node_list.append(r)
            # resp = Tor.TorPacket(dst=self.IPAddr, dstPort=self.port, reqType=Tor.TorActions.NA)
            resp = TorDirectoryPacket(action=DirectoryActions.RegisterResp, payload=None, success=True)
            return pickle.dumps(resp)
        elif(packet.action == DirectoryActions.FetchReq):
            relays = list()
            def is_in_relays(ip):
                for relay in relays:
                    if relay.ip == ip:
                        return True
                return False
            for i in range(3):
                node: RelayServerDetails = random.choice(self.relay_node_list)
                while node.ip == address or is_in_relays(node.ip):
                    node: RelayServerDetails = random.choice(self.relay_node_list)
                relays.append(node)
        
            # payload = pickle.dumps(relays)
            resp = TorDirectoryPacket(action=DirectoryActions.FetchResp, payload=relays, success=True)
            return pickle.dumps(resp)
        else:
            resp = TorDirectoryPacket(action=DirectoryActions.NA, payload=None, success=False)
            return pickle.dumps(resp)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('Format: <script_name> <port_no>')
    port = int(sys.argv[1])
    dir_service = DirectoryService(port)
    dir_service.startListening()